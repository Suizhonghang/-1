#! /bin/bash 
gcc test.c -o test.o
