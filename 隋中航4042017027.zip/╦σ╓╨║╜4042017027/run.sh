#! /bin/bash
./compile.sh
./test.o $@
